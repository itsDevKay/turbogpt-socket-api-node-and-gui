import logging

logger = logging.getLogger("base")

logger.setLevel(logging.INFO)
